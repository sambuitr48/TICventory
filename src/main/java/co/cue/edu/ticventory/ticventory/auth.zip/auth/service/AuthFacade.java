package co.cue.edu.ticventory.ticventory.auth.service;

public class AuthFacade {
    private final AuthProxy authProxy;

    public AuthFacade(AuthProxy authProxy) {
        this.authProxy = authProxy;
    }

    public boolean login(String username, String password) {
        return authProxy.authenticate(username, password);
    }

    public void logout() {
        AuthService.getInstance().logout();
    }
}
