package co.cue.edu.ticventory.ticventory.auth.domain;

public enum AuthRole {
    ADMIN,
    USER,
    GUEST
}
