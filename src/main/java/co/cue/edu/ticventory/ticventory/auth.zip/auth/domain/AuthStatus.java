package co.cue.edu.ticventory.ticventory.auth.domain;

public enum AuthStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
